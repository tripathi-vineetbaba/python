import sys
import os
sys.path.insert(0,"/home/vineet/Git/function")
import guessandplay
import nextline
import nexttab
ch="2"
while(ord(ch)!=49 or ch==""):
 os.system("clear")
 for x in range(0,8):
  print	
 nexttab.tab(4,"Welcome to GUESS & PLAY")
 nextline.line(1)
 nexttab.tab(5,"Rules:")
 nextline.line(1)
 nexttab.tab(1,"1. Think of an integer between 0 to 100")
 nexttab.tab(1,"2. If computer cannot guess the number in less than 10 attemp, You Win")
 nexttab.tab(1,"3. If computer guesses the number in less than 10 attempt, You Lose")
 gues=raw_input("\n\t\t\t\t\tPress Enter to Begin...")
 if (gues==""):
  os.system("clear")
  ll=0
  hl=100
  choice=2
  num=0
  choic=0
  guessed=guessandplay.guess(ll,hl)
  while(choice!=1):
 	os.system("clear")
#	guessed=guessandplay.guess(ll,hl)
	nextline.line(9)
	print"\t\t\t\t\tIs your number:",guessed
	print
	print"\t\t\t\t\tEnter 1 if yes"
	print"\t\t\t\t\tEnter 2 if no"

	num+=1
	choice=int(input("\t\t\t\t\t\t"))
	if (choice==2):
		os.system("clear")
	#	choic=1
		nextline.line(9)
		print"\t\t\t\tEnter 1 if your number is greater than",guessed
		print"\t\t\t\tEnter 2 if your number is less than",guessed
		choic=int(input("\t\t\t\t\t"))
		if(choic==1):
		 ll=guessed
		 print ll
		 guessed=guessandplay.guess(ll,hl)
		elif(choic==2):
		 hl=guessed
		 guessed=guessandplay.guess(ll,hl)
	elif(choice==1):
		os.system("clear")
		if(num<10):
		 for y in range(0,10):
		  print
		 print"  \t\t\t\tYou lose!!!"
		 print
		 print" \t\t\t\tYour number was guessed in",num," attempt."
		 print"\n\t\t\t\tPress 1 to exit or anykey to continue:"
		 ch=raw_input("\t\t\t\t\t")
		if(num>=10):
		 for y in range(0,10):
                  print
                 print"  \t\t\t\tYou lose!!!"
                 print
                 print" \t\t\t\tYour number was guessed in",num," attempt."
                 print"\n\t\t\t\tPress 1 to exit or anykey to continue:"
                 ch=raw_input("\t\t\t\t\t")
		if(ch==""):
		 ch="0"
