import os,sys
sys.path.insert(0,'/home/vineet/Git/Classes/')
import scoring
from scoring import person


def tab(n,msg):
    for x in range(n):
     print '\t',
    print msg

def line(n):
    for x in range(n):
     print '\n'

def welcome():
    os.system("clear")
    line(5)
    tab(5,"WELCOME TO RAM SITA GAME")
    line(2)
    tab(5,"Press enter to continue!!")

def hyph():
    print "     ------------------------------------------------------------------------------------"

def vert(x,n,m,o,p):
    t='    |      '
    hyph()
#    print t.rjust(2)+str(x+1)+t.rjust(3)+str(n)+t.rjust(3,)+str(m)+t.rjust(3)+str(o)+t.rjust(3)+str(p)+t.rjust(3)
    print "     |   "+str(x+1)+"          |      "+str(n)+"     |       "+str(m)+"       |     "+str(o)+"        |    "+str(p)+"         |  "
    hyph()

def objName(p1,p2,p3,p4):
    os.system("clear")
    line(2)
    t='     |     '
    hyph()
    print t.rjust(2)+"S.No"+t.rjust(3)+p1.getName()+t.rjust(3,)+p2.getName()+t.rjust(3)+p3.getName()+t.rjust(3)+p4.getName()+t.rjust(3)
    hyph()
def objName1(p1,p2,p3,p4):
#    os.system("clear")
    line(2)
    t='     |     '
    hyph()
    print t.rjust(2)+"S.No"+t.rjust(3)+p1.getName()+t.rjust(3,)+p2.getName()+t.rjust(3)+p3.getName()+t.rjust(3)+p4.getName()+t.rjust(3)
    hyph()




def objDisp(p1,p2,p3,p4):
    
    for x in range(len(p1.getScore())): 
        m=p1.getscore(x)
        n=p2.getscore(x)
        o=p3.getscore(x)
        p=p4.getscore(x)
        vert(x,m,n,o,p)
    
def checknum(s):
        if str(s).isdigit():
          return True
        else:
          return False
def checkstr(s):
        if(not(str(s).isdigit())):
         test=len(s)
         while(test>=0):
          if s[test-1] in 'abcdefghijklmnopqrstuwvxyz':
             test-=1
          else:
              return False
         return True
        else:
         return False
def enterName():
        os.system("clear")
        line(4)
        tab(5,"Enter Name of player 1:")
        p1=raw_input("\t\t\t\t\t")
        line(1)
        tab(5,"Enter name of player 2:")
        p2=raw_input("\t\t\t\t\t")
        line(1)
        tab(5,"Enter name of player 3:")
        p3=raw_input('\t\t\t\t\t')
        line(1)
        tab(5,"Enter name of player 4:")
        p4=raw_input("\t\t\t\t\t")
        line(1)

       # time.sleep(5)
        drama=False
        while(drama!=True):
             os.system("clear")
             line(3)
             tab(5,"Enter score for "+p1+" :")
             s1=raw_input("\t\t\t\t\t")
             line(1)
             tab(5,"Enter score for "+p2+" :")
             s2=raw_input("\t\t\t\t\t")
             line(1)
             tab(5,"Enter score for "+p3+" :")
             s3=raw_input("\t\t\t\t\t")
             line(1)
             tab(5,"Enter score for "+p4+" :")
             s4=raw_input("\t\t\t\t\t")
             line(1)
             drama=checknum(s1)
             drama=checknum(s2)
             drama=checknum(s3)
             drama=checknum(s4)
             per1=scoring.person(p1,int(s1))
             per1.addScore(int(s1))
             per2=scoring.person(p2,s2)
             per2.addScore(int(s2))
             per3=scoring.person(p3,s3)
             per3.addScore(int(s3))
             per4=scoring.person(p4,s4)
        
        per4.addScore(int(s4))
        return [per1,per2,per3,per4]
def wanna(p1,p2,p3,p4):
        drama=False
        while(drama!=True):
             os.system("clear")
             
             line(3)
             tab(5,"Enter score for "+p1.getName()+" :")
             s1=raw_input("\t\t\t\t\t")
             line(1)
             tab(5,"Enter score for "+p2.getName()+" :")
             s2=raw_input("\t\t\t\t\t")
             line(1)
             tab(5,"Enter score for "+p3.getName()+" :")
             s3=raw_input("\t\t\t\t\t")
             line(1)
             tab(5,"Enter score for "+p4.getName()+" :")
             s4=raw_input("\t\t\t\t\t")
             line(1)
             drama=checknum(s1)
             drama=checknum(s2)
             drama=checknum(s3)
             drama=checknum(s4)
             print drama
             if drama==False:
                     tab(5,'Enter Correct choice!!!')
                     tab(5,'Press Enter to continue')
                     ch=raw_input('\t\t\t\t\t')
                     if(ch==""):
                       os.system('clear')
                       wanna(p1,p2,p3,p4)
                     else:
                       break
             else:
                     p1.addScore(int(s1))
                     p2.addScore(int(s2))
                     p3.addScore(int(s3))
                     p4.addScore(int(s4))
                   #  choiceS()
                     
def choiceS():
          #  os.system("clear")
            line(5)
            tab(5,"Press enter to continue inserting Score")
            line(1)
            tab(5,"Enter 'e' to calculate sum and exit.")
            line(1)
            ch=raw_input("")
            if (ch==""):
                     return True
            elif(ch=='e'):
                     return False
            else:
                     choiceS()
def calcSum(p1,p2,p3,p4):
            
            a=p1.sumScore()
            b=p2.sumScore()
            c=p3.sumScore()
            d=p4.sumScore()
            os.system("clear")
            line(2)
            print "**********************************************TOTAL***************************************************"
            objName1(p1,p2,p3,p4)
            vert(len(p1.getScore()),a,b,c,d)
            if (max(a,b,c,d)==a):
               k=p2
               if(max(b,c,d)==c):
                k=p3
               elif(max(b,c,d)==d):
                k=p4
               winner(p1,k)
            elif (max(a,b,c,d)==b):
               k=p1
               if(max(b,c,d)==c):
                k=p3
               elif(max(b,c,d)==d):
                k=p4
               winner(p2,k)
            elif (max(a,b,c,d)==c):
               k=p1
               if(max(b,c,d)==b):
                k=p2
               elif(max(b,c,d)==d):
                k=p4
               winner(p3,k)
            elif (max(a,b,c,d)==d):
               k=p1
               if(max(b,c,d)==c):
                k=p3
               elif(max(b,c,d)==b):
                k=p2
               winner(p4,k)

            
               


def winner(p1,p2):
            
            line(2)
            print"\t|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"

            print"\t|",

            print"                       WINNER => "+p1.getName()+"                               |"
            print"\t|*******************************************************************************|"

            print"\t|                       RUNNER => "+p2.getName()+"                               |"

            print"\t|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"



