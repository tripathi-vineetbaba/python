class person:
    name=''
    age=0
    sex=''
    score=[0]
#    def __init__(self,name,age,sex,score):
#             self.name=name
#             self.age=age
#             self.sex=sex
#             self.score=score
    def __init__(self,name,score):
             self.name=name
             self.score=[]
    def getName(self):
             return self.name
    def getScore(self):
             return self.score
    def getAge(self):
             return self.age
    def getSex(self):
             return self.sex
    def setName(self,name):
             self.name=name
    def setAge(self,age):
             self.age=age
    def setSex(self,sex):
             self.sex=sex
    def setScore(self,score):
             self.score=score
    def addScore(self,scorei):
             self.score.append(scorei)
    def deleteScore(self):
             self.score.pop()
    def sumScore(self):
             test=0 
             for x in range(len(self.score)):
              test+=self.score[x]
             return test
    def getscore(self,x):
             return self.score[x]
#    def getScore(self,ii):
#             return self.score(ii)
