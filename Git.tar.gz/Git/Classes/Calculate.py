import os,sys
sys.path.insert(0,'/home/vineet/Git/Classes/')
import scoring
import function
import time
ch='y'
while (str(ch).lower()!='n'):
               # check=False
               # while(not check):
                 function.welcome()
                 choice=raw_input("")
                 if (choice==''):
                      pers= function.enterName()
                      function.objName(pers[0],pers[1],pers[2],pers[3])
                      function.objDisp(pers[0],pers[1],pers[2],pers[3]) 
#                      ch=function.choiceS(pers[0],pers[1],pers[2],pers[3])
                      time.sleep(1)
                      ch=function.choiceS()
                      if (ch):
                       while(ch==True):
                          function.wanna(pers[0],pers[1],pers[2],pers[3])
                          function.objName(pers[0],pers[1],pers[2],pers[3])
                          function.objDisp(pers[0],pers[1],pers[2],pers[3])
                          ch=function.choiceS()
                     
                      function.calcSum(pers[0],pers[1],pers[2],pers[3])





                 ch=input("\t\t\t\t\t\tEnter choice[y/n]")
                 check=function.checkstr(ch)
                 print check
