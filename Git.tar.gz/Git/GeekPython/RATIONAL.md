This course is designed to support kids new to Python and typed programming. The typical student will be 10 with limited typing skills (generally knows the layout of the keys, but can't do much typing without looking at the keys).

The goal is to limit the time spent lecturing and the typing required. This will be done by providing completed example programs that will be edited.
