We will introduce PyGame by first drawing random shapes and colors on the screen.
