The goal for this class is to introduce lists and functions.
