
adj1 = raw_input("Enter an adjective: ")
adj2 = raw_input("Enter an adjective: ")
adj3 = raw_input("Enter an adjective: ")
adj4 = raw_input("Enter an adjective: ")
adj5 = raw_input("Enter an adjective: ")
name1 = raw_input("Enter a name: ")
name2 = raw_input("Enter a name: ")
name3 = raw_input("Enter a name: ")
name4 = raw_input("Enter a name: ")
number1 = raw_input("Enter a number: ")
number2 = raw_input("Enter a number: ")
number3 = raw_input("Enter a number: ")
plural_noun1 = raw_input("Enter a plural noun: ")
plural_noun2 = raw_input("Enter a plural noun: ")
plural_noun3 = raw_input("Enter a plural noun: ")
plural_noun4 = raw_input("Enter a plural noun: ")
past_tense_verb = raw_input("Enter a past tense verb: ")
noun =  raw_input("Enter a noun: ")
animal1 = raw_input("Enter an animal: ")
animal2 = raw_input("Enter an animal: ")


print ""
print "Make Me A Video Game MadLib!"
print "I, the", adj1, "and", adj2, name1 + ", has", past_tense_verb, name2 + "'s sister and plans"
print "to steal her", adj3, noun + "! What are a", animal1, "and backpacking", animal2
print "to do? Before you can help", name3, "you'll have to collect the", adj4
print plural_noun1,"and",adj5, plural_noun2, "that open up the", number1, "worlds connected to"
print name4 + "'s Lair. There are", number2, plural_noun3, "and", number3, plural_noun4, "in the game,"
print "along with hundreds of other goodies for you to find."
