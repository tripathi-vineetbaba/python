The goal for this class is to introduce loops and gain more experience with variables and conditionals.
