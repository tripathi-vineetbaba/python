The first goal is to get them writing code right away.

We will talk about variable types by using input and raw_input.

We will introduce most programming concepts by reading the guessing game code. These include loops, conditionals, and importing modules

The goal of the two projects is to give them a lot of code to look at for examples how to solve problems. Any time they have a question and we can ask "where have you done something similar before, go look at that code", they are able to do critical thinking and solve things themselves.

