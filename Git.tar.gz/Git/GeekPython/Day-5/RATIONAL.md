
Animation is important to games, so we will start here. Get an image to move across the screen and do something when it gets to the other side (like start over or head back in the same direction).
