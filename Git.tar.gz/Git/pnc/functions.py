import os,sys

def input():
           inpu=raw_input("\t\t\tEnter string to find permitation: ")
           

def checkstr(s):
           if s.lower() in "abcdefghijklmnopqrstuvwxyz":
              return True
           else:
              return False

def get_pnc(s):
           txt=list(s)
           msg=txt[:]
           
