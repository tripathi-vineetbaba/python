'''This function is to multiply and play'''
import random
def randmul():
           a=random.randint(1,16)
           b=random.randint(1,16)
           print"\t\t\t\tWhat will be the answer for",a,"x",b 
           return (a*b)
