import sys
import os
sys.path.insert(0,"/home/vineet/Git/multiplyandplay/function")
import multiplyandplay
import nextline
import nexttab
import loading
nextline.line(2)
loading.animate()
ch="2"
while(ord(ch)!=49 or ch==""):
 os.system("clear")
 for x in range(0,8):
  print
 nexttab.tab(4,"Welcome to MULTIPLY & PLAY")
 nextline.line(4)
 gues=raw_input("\n\t\t\t\t\tPress Enter to Begin...")
 if (gues==""):
  counter=0
  for x in range (1,12):
   
   os.system("clear")
   nextline.line(8)
   d=multiplyandplay.randmul()
   print
 #  nexttab.tab(5,"Answer:"),
   guess=int(input("\t\t\t\t\tAnswer: "))
   chance=0
   while(guess!=d or chance==3):
    os.system("clear")
    nextline.line(8)
    nexttab.tab(5,"Enter correct answer")
    nextline.line(2)
    d=multiplyandplay.randmul()
    guess=int(input("\t\t\t\t\tAnswer:"))
    chance+=1
   if(guess==d):
    counter+=1
  if(counter>=9):
    print "\n\n\n\n\n\n\n\t\t\t\t\t\tWell done!!!!"
    print"\t\t\t\t\t\t\tYou scored:",counter
  else:
    print"\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\tTry harder"
    nexttab.tab(7,"Better luck next time")
