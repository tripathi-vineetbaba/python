import function
import os


os.system("clear")
function.line(4)
print"    8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888"
print"    8                                                                                                  8"
print"    8                              CIPHER LIKE CAESAR                                                  8"
print"    8                                                                                                  8"
print"    8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888"
choice=raw_input("\t\t\t\tPress enter to continue: ")
if choice=='':
   os.system("clear")
   function.line(4)
   rand=raw_input("\t\t\tEnter your string to cipher: ")
   ciph=function.cipher(rand)
   os.system("clear")
   print"\t\t\t\t Your ciphered text is given below:"
   function.line(2)
   print"\t\t",
   for x in ciph:
    print x,
