import os,sys

def cipher(i):
      s="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
      m1=list(s)
      m5=list(s.lower())
      m2=list(i)
      m4=m1[:]
      m3=m2[:]
      m6=m5[:]
      for x in range(len(i)):
        if m2[x] in m1 :
          c=m2[x]
          k=m1.index(c)
          m3[x]=m4[k-3]
        elif m2[x]=='':
          m3[x]=' '
        elif m2[x] in m5:
          c=m2[x]
          k=m5.index(c)
          m3[x]=m6[k-3]
      return m3

def tab(n,msg):
      for x in range(n):
          print"\t",
      print msg

def line(n):
      for x in range(n):
          print

