def line(n):
	for x in range(0,n+1):
		print
