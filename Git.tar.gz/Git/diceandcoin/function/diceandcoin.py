import random


def dice():
    return(random.randint(1,6))

def coin():
    a=random.randint(1,2)
    if a==1:return "Head"
    elif a==2:return "Tail"
