import itertools
import threading
import time
import sys
import os
sys.path.insert(0,"/home/vineet/Git/function/")
import nextline
done = False
def animate():
    for c in range(0,110,10):#, '   ', '....', '   ']):
        if done:
            break
	os.system("clear")
	nextline.line(9)
        sys.stdout.write("\t\t\tLoading")
	for y in ([' ----------------------------------> ']):
	 sys.stdout.write(y)
	sys.stdout.write(str(c)+"%")
        sys.stdout.flush()
        time.sleep(0.6)
    
    sys.stdout.write('     ')

t = threading.Thread(target=animate)
t.start()

#long process here
time.sleep(7.5)
done=True

