def tab(n,msg):
 for x in range (0,n+1):
  print"\t",
 print msg
