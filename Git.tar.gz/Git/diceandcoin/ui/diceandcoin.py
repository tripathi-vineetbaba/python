import sys
import os
sys.path.insert(0,"/home/vineet/Git/diceandcoin/function")
import diceandcoin
import nextline
import nexttab
import loading
nextline.line(2)
loading.animate()
ch="2"
while(ord(ch)!=49 or ch==""):
 os.system("clear")
 for x in range(0,8):
  print
 nexttab.tab(4,"Welcome to DICE & COIN WORLD")
 nextline.line(4)
 gues=raw_input("\n\t\t\t\t\tPress Enter to Begin...")
 if (gues==""):
          os.system("clear")
          nextline.line(8)
          choice='0'
          counter=0
          
          while(ord(choice) not in [49,50]):
           # os.system("clear")
           # nextline.line(8)
            nexttab.tab(5,"Enter 1 to roll a dice")
            nexttab.tab(5,"Enter 2 to toss a coin")
            choice=raw_input("\t\t\t\t\t\tChoice: ")
           
            if (ord(choice)!=49 and ord(choice)!=50):
             os.system("clear")
             nextline.line(8)
             counter+=1
             nexttab.tab(5,"Please enter valid choice")
             print
             nexttab.tab(5,"You have "+str(3-counter)+" more attempts")
             if(counter==3):
              exit()
             nextline.line(2)
             
          if(ord(choice)==49):
           des='m'
           while(des!='e'):
            d=diceandcoin.dice()
            if(d==1):
             os.system("clear")
             nextline.line(8)
             nexttab.tab(5,'@')
            if(d==2):
             os.system("clear")
             nextline.line(8)
             nexttab.tab(5,"@ @")
            if(d==3):
             os.system("clear")
             nextline.line(8)
             nexttab.tab(5,"@ @ @")
            if(d==4):
             os.system("clear")
             nextline.line(8)
             nexttab.tab(5,"@ @")
             nexttab.tab(5,"@ @")
            if(d==5):
             os.system("clear")
             nextline.line(8)
             nexttab.tab(5,"@ @")
             nexttab.tab(5," @")
             nexttab.tab(5,"@ @")
            if(d==6):
             os.system("clear")
             nextline.line(8)
             nexttab.tab(5,"@ @ @")
             print
             nexttab.tab(5,"@ @ @")
            # nexttab.tab(5,"@ @")
            des=raw_input("\n\n\n\t\t\t\t\tEnter e to exit rolling dice: ")
          if(ord(choice)==50):
           des='m'
           while(des!='e'):
            d=diceandcoin.coin()
            os.system("clear")
            nextline.line(8)
            nexttab.tab(5,d)
            des=raw_input("\n\n\n\t\t\t\t\tEnter e to exit toss: ")
          ch=raw_input("\n\n\t\t\t\tEnter 1 to Exit or anykey to continue: ")
