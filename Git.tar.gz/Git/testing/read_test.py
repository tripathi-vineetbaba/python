import sys
sys.path.insert(0,"/home/vineet/Git/")
#import words

test=open("/home/vineet/Git/words.txt","wb+")
#test.write("This is test writing of file in not python");
#test.write("\n\nThis is not end of the file.:)")
test1=open("/home/vineet/Git/testing/words1.txt","rb+")
tryi=test1.read();
test.write(tryi+"This is testing")
#tryi.write("\n\nThis is end of file")
#print tryi

test.close()
#print test
