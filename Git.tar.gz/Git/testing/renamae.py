import os,sys

#os.system("clear")
owl=['run_by=user','owned_by=user','ax','ar']
string=open("/home/vineet/Git/testing/words1.txt","rb+")
newstr=string.read()
string1=open("/home/vineet/Git/testing/words1.txt","rb+")
for x in string1:
 for k in owl: 
    if 'run_by=user' in x and k=='run_by=user':
      newstr=newstr.replace(k,"run_by=vineet")
    if 'owned_by=user' in x and k=='owned_by=user':
      newstr=newstr.replace(k,"run_by=vineet tripathi")
#print newstr
 # test=open("testw.txt","wb+")
   #test.write(temp)
 # test.close()
 # test1=open("testw.txt","rb+")
#  print newstr
    else:
      print"Not found"
print newstr
