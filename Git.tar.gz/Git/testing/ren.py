import os,sys

os.system("clear")
owl=['ad','am','an','ad','ax','ar']
string=open("/home/vineet/Git/testing/words1.txt","rb+")
#newstr=string.read()
#print newstr
for x in string:
 
# os.system("more x")
 newstr=x
# print newstr
 for k in owl: 
  if k in x:
   print "Current position=> ",string.tell()
 #  newstr=string.read()
 #  print newstr
   newstr=newstr.replace(k,"zinda")
   print newstr
   test=open("testw.txt","wb+")
   #test.write(temp)
   test.close()
   test1=open("testw.txt","rb+")
   newstr=test1.read()

   print (newstr)
   print' xyz'
  else:
   print"Not found"
