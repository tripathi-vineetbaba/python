def guess(ll,hl):
	return int(round((ll+hl)/2))

